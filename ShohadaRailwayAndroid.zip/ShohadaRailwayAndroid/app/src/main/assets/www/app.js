const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const STORAGE_KEY = "shohada-railway-pwa-v1";
const DAYS = ["شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه"];
const starter = {
 announcements:[
  {id:1,title:"به سامانه همراه هنرستان خوش آمدید",category:"عمومی",body:"این سامانه نسخه نمایشی اطلاع‌رسانی هنرستان شهدا راه‌آهن است. اطلاعیه‌های رسمی را از طریق مدرسه پیگیری کنید.",date:"۱۴۰۵/۰۷/۲۰"},
  {id:2,title:"یادآوری: برنامه هفتگی را بررسی کنید",category:"آموزشی",body:"برنامه نمایش‌داده‌شده نمونه است و باید توسط مسئول مدرسه تأیید و به‌روزرسانی شود.",date:"۱۴۰۵/۰۷/۲۰"}
 ],
 schedule:[
  ["شنبه","فارسی، ریاضی","دانش فنی","کارگاه"],
  ["یکشنبه","زبان انگلیسی","تربیت بدنی","کارگاه"],
  ["دوشنبه","ریاضی","دانش فنی","آزمایشگاه"],
  ["سه‌شنبه","دینی","کارگاه","کارگاه"],
  ["چهارشنبه","فارسی","آمادگی دفاعی","دانش فنی"],
  ["پنجشنبه","مهارت تخصصی","مهارت تخصصی","پروژه"]
 ],
 projects:[
  {id:1,title:"طراحی وب‌سایت هنرستان",author:"گروه نمونه هنرجویان",body:"ایده‌ای برای معرفی رشته‌ها، نمایش خبرها و ارائه نمونه‌کارهای هنرجویان."},
  {id:2,title:"سامانه برنامه هفتگی",author:"پروژه نمونه",body:"طراحی یک رابط ساده برای مشاهده برنامه کلاس‌ها در تلفن همراه."}
 ],
 homework:[
  {id:1,title:"تمرین درس تخصصی",due:"طبق اعلام دبیر",body:"تمرین‌های تعیین‌شده در کلاس را انجام دهید. این مورد نمونه است."}
 ]
};
let data = loadData();
let deferredInstallPrompt = null;
function loadData(){try{const raw=localStorage.getItem(STORAGE_KEY);return raw?JSON.parse(raw):structuredClone(starter)}catch(e){return JSON.parse(JSON.stringify(starter))}}
function saveData(){localStorage.setItem(STORAGE_KEY,JSON.stringify(data))}
function escapeHTML(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function showToast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>el.classList.remove("show"),2600)}
function renderAnnouncements(){
 const el=$("#announcementList");$("#announcementCount").textContent=`${data.announcements.length.toLocaleString("fa-IR")} مورد`;
 el.innerHTML=data.announcements.length?data.announcements.map(a=>`<article class="item-card"><div class="item-meta"><span class="tag">${escapeHTML(a.category)}</span><span>${escapeHTML(a.date||"")}</span></div><h3>${escapeHTML(a.title)}</h3><p>${escapeHTML(a.body)}</p></article>`).join(""):'<div class="empty">فعلاً اطلاعیه‌ای ثبت نشده است.</div>';
}
function renderSchedule(){
 $("#scheduleBody").innerHTML=data.schedule.map(row=>`<tr>${row.map((cell,i)=>`<td>${escapeHTML(cell)}</td>`).join("")}</tr>`).join("");
 $("#scheduleForm").innerHTML=data.schedule.map((row,i)=>`<label class="full">${escapeHTML(row[0])}<input data-day="${i}" value="${escapeHTML(row.slice(1).join("، "))}" aria-label="برنامه ${escapeHTML(row[0])}"></label>`).join("");
}
function renderProjects(){
 $("#projectList").innerHTML=data.projects.length?data.projects.map(p=>`<article class="item-card"><div class="item-meta"><span class="tag">پروژه دانش‌آموزی</span></div><h3>${escapeHTML(p.title)}</h3><p>${escapeHTML(p.body)}</p><p style="margin-top:12px;font-size:12px">تهیه‌کننده: ${escapeHTML(p.author||"ثبت نشده")}</p></article>`).join(""):'<div class="empty">هنوز پروژه‌ای ثبت نشده است.</div>';
}
function renderHomework(){
 $("#homeworkList").innerHTML=data.homework.length?data.homework.map(h=>`<article class="item-card"><div class="item-meta"><span class="tag">تکلیف</span><span>مهلت: ${escapeHTML(h.due||"اعلام نشده")}</span></div><h3>${escapeHTML(h.title)}</h3><p>${escapeHTML(h.body)}</p></article>`).join(""):'<div class="empty">تکلیفی ثبت نشده است.</div>';
}
function render(){renderAnnouncements();renderSchedule();renderProjects();renderHomework()}
$$(".tab").forEach(btn=>btn.addEventListener("click",()=>{$$(".tab").forEach(b=>b.classList.toggle("active",b===btn));$$(".page").forEach(p=>p.classList.toggle("active",p.id===btn.dataset.page));if(btn.dataset.page==="admin")$("#adminPassword").focus()}));
const isLoggedIn=()=>sessionStorage.getItem("shohada-admin-demo")==="yes";
function updateAdminView(){$("#adminLogin").classList.toggle("hidden",isLoggedIn());$("#adminDashboard").classList.toggle("hidden",!isLoggedIn())}
$("#loginForm").addEventListener("submit",e=>{e.preventDefault();if($("#adminPassword").value==="1234"){sessionStorage.setItem("shohada-admin-demo","yes");$("#loginError").textContent="";$("#adminPassword").value="";updateAdminView();showToast("ورود نمایشی انجام شد")}else $("#loginError").textContent="رمز واردشده درست نیست."});
$("#logoutBtn").addEventListener("click",()=>{sessionStorage.removeItem("shohada-admin-demo");updateAdminView();showToast("از پنل خارج شدید")});
$("#announcementForm").addEventListener("submit",e=>{e.preventDefault();if(!isLoggedIn())return;const f=new FormData(e.currentTarget);data.announcements.unshift({id:Date.now(),title:f.get("title").trim(),category:f.get("category"),body:f.get("body").trim(),date:new Intl.DateTimeFormat("fa-IR").format(new Date())});saveData();render();e.currentTarget.reset();showToast("اطلاعیه ثبت شد")});
$("#homeworkForm").addEventListener("submit",e=>{e.preventDefault();if(!isLoggedIn())return;const f=new FormData(e.currentTarget);data.homework.unshift({id:Date.now(),title:f.get("title").trim(),due:f.get("due").trim(),body:f.get("body").trim()});saveData();render();e.currentTarget.reset();showToast("تکلیف ثبت شد")});
$("#projectForm").addEventListener("submit",e=>{e.preventDefault();if(!isLoggedIn())return;const f=new FormData(e.currentTarget);data.projects.unshift({id:Date.now(),title:f.get("title").trim(),author:f.get("author").trim(),body:f.get("body").trim()});saveData();render();e.currentTarget.reset();showToast("پروژه ثبت شد")});
$("#saveSchedule").addEventListener("click",()=>{if(!isLoggedIn())return;data.schedule=data.schedule.map((row,i)=>[row[0],...($("#scheduleForm").querySelector(`[data-day="${i}"]`).value.split(/[،,]/).map(s=>s.trim()).filter(Boolean))]);data.schedule=data.schedule.map(row=>[row[0],row[1]||"—",row[2]||"—",row[3]||"—"]);saveData();render();showToast("برنامه هفتگی ذخیره شد")});
$("#resetBtn").addEventListener("click",()=>{if(!isLoggedIn())return;if(confirm("همه تغییرات این مرورگر حذف و اطلاعات نمونه جایگزین شود؟")){data=JSON.parse(JSON.stringify(starter));saveData();render();showToast("اطلاعات نمونه بازگردانی شد")}});
updateAdminView();render();
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstallPrompt=e;$("#installBtn").classList.remove("hidden")});
$("#installBtn").addEventListener("click",async()=>{if(!deferredInstallPrompt)return;deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;$("#installBtn").classList.add("hidden")});
if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(err=>console.warn("Service worker:",err)))}
